In this files we present the Effective Fluid modifications of the CLASS code, which we called EFCLASS, used in the analysis of the papers 1811.02469 and 1904.06294, see Refs [1],[2].

To build the various versions of the code (check the Makefile for more details) you can use the makefile by typing "make" and one of the following options: 

class   : The default version
	
classfRDES : The designer f(R) model

classHS  : The Hu-Sawicki model
	
classHDES: The Horndeski designer model

eg, type "make class" (without quotes "") to build the default version or "make classHS" for the Hu-Sawicki model. To run the codes, use one of the .ini files, eg lcdm_fRDES.ini for the f(R) designer model etc.
All of the files are provided "as available", with no warranty what so ever.

For any questions  you can contact me at ruben.arjona@uam.es

[1] https://arxiv.org/abs/1811.02469
[2] https://arxiv.org/abs/1904.06294

EFCLASS can also be found at: https://members.ift.uam-csic.es/savvas.nesseris/efclass.html and https://github.com/wilmarcardonac/EFCLASS